# mod_bearscards
Bootstrap 3 version of Bootstrap 4 cards

Designed to mimic a simple bootstrap 4 image card for bootstrap 3.

![sample](https://github.com/N6REJ/mod_bearscards/blob/master/sample.png)
